export const locales = ['vi', 'en'];
export const defaultLocale = 'vi';
