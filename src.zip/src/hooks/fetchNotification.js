export async function fetchNotifications(token, page = 0, size = 10) {
  const res = await fetch(
    `${process.env.NEXT_PUBLIC_API_URL}/v1/notifications?page=${page}&size=${size}`,
    {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  if (!res.ok) {
    throw new Error("Failed to fetch notifications");
  }

  return await res.json(); // { content: Notification[], ... }
}
