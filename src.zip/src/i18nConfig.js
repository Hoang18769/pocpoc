module.exports = {
  locales: ["en", "vi"],
  defaultLocale: "vi",
};
